﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheWorld.Controllers.Api
{
    [Route("/api/trips/employee")]
    public class employeeController
    {
        public String Index()
        {
            return "xxxx - xxxx - xxxxx";
        }
    }
}
