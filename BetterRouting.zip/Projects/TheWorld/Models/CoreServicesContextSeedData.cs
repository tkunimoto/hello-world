﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using TheWorld.Models;
using System;

namespace TheWorld
{
    public class CoreServicesContextSeedData
    {
        private CoreServicesContext _context;

        public CoreServicesContextSeedData(CoreServicesContext context)
        {
            _context = context;
        }

        public async Task EnsureSeedData()
        {
            if (!_context.Users.Any())
            {
                var coreServiceUser = new Employee()
                {

                    FirstName = "Toshi",
                    LastName = "Kunimoto",                    
                    BirthDate = Convert.ToDateTime("06/30/1953"),
                    PIN = "791009",
                    ServiceCompDate= Convert.ToDateTime("09/20/2004"),

                };

                _context.Users.Add(coreServiceUser);
                await _context.SaveChangesAsync();
            }
        }
    }
 }