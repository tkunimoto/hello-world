using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace TheWorld.Models
{
    public class CoreServicesContext : DbContext
    {

        private IConfigurationRoot _config;
        //public TripImageContext(DbContextOptions<TripImageContext> options)
        //    : base(options)
        //{ }
        public CoreServicesContext(IConfigurationRoot config, DbContextOptions<CoreServicesContext> options) 
          : base(options)
          {
                _config = config;
           }

        public DbSet<Employee> Users { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

            optionsBuilder.UseSqlServer(_config["ConnectionStrings:CoreServicesContextConnection"]);
        }

    }

}
